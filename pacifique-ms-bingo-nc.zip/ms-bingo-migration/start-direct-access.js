/**
 * Script de démarrage pour l'accès direct à MS BINGO
 * Ce script exécute direct-access-fix.js pour contourner les problèmes de redirection
 */
require('./direct-access-fix.js');