/**
 * Script de démarrage pour MS BINGO avec KYC intégré
 * Ce script démarre le serveur MS BINGO avec la fonctionnalité de vérification d'identité (KYC)
 */

console.log('Démarrage de MS BINGO avec le système KYC intégré...');

require('./server');

console.log('Script de démarrage KYC terminé.');