/**
 * PACIFIQUE MS BINGO - Point d'entrée
 * Version: 16 avril 2025
 */

// Démarrer le serveur de l'interface de jeu
console.log('Démarrage du serveur PACIFIQUE MS BINGO...');
require('./serveur.js');