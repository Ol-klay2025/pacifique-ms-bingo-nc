/**
 * MS BINGO PACIFIQUE - Client API
 * Gère les requêtes HTTP vers l'API de conformité
 */

// Configuration de base
const API_BASE_URL = '';

// Classe client API
class ApiClient {
  constructor() {
    this.baseUrl = API_BASE_URL;
    this.authToken = null;
  }

  // Configure le token d'authentification
  setAuthToken(token) {
    this.authToken = token;
  }

  // Crée les en-têtes HTTP pour les requêtes
  getHeaders() {
    const headers = {
      'Content-Type': 'application/json',
      'Accept': 'application/json'
    };

    if (this.authToken) {
      headers['Authorization'] = `Bearer ${this.authToken}`;
    }

    return headers;
  }

  // Effectue une requête GET
  async get(endpoint, params = {}) {
    const url = new URL(this.baseUrl + endpoint, window.location.origin);
    
    // Ajouter les paramètres de requête s'il y en a
    if (Object.keys(params).length > 0) {
      Object.keys(params).forEach(key => {
        if (params[key] !== undefined && params[key] !== null) {
          url.searchParams.append(key, params[key]);
        }
      });
    }

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw {
        status: response.status,
        message: errorData.message || response.statusText,
        response
      };
    }

    return response.json();
  }

  // Effectue une requête POST
  async post(endpoint, data) {
    const response = await fetch(this.baseUrl + endpoint, {
      method: 'POST',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw {
        status: response.status,
        message: errorData.message || response.statusText,
        response
      };
    }

    return response.json();
  }

  // Effectue une requête PUT
  async put(endpoint, data) {
    const response = await fetch(this.baseUrl + endpoint, {
      method: 'PUT',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw {
        status: response.status,
        message: errorData.message || response.statusText,
        response
      };
    }

    return response.json();
  }

  // Effectue une requête PATCH
  async patch(endpoint, data) {
    const response = await fetch(this.baseUrl + endpoint, {
      method: 'PATCH',
      headers: this.getHeaders(),
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw {
        status: response.status,
        message: errorData.message || response.statusText,
        response
      };
    }

    return response.json();
  }

  // Effectue une requête DELETE
  async delete(endpoint) {
    const response = await fetch(this.baseUrl + endpoint, {
      method: 'DELETE',
      headers: this.getHeaders(),
    });

    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw {
        status: response.status,
        message: errorData.message || response.statusText,
        response
      };
    }

    return response.json();
  }
}

// Exporter une instance unique
const api = new ApiClient();
export default api;