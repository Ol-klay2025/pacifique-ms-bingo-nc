/**
 * MS BINGO PACIFIQUE - Script de lancement
 * Version: 15 avril 2025
 * 
 * Ce fichier sert de point d'entrée pour Replit et appelle le script index.js
 */

console.log('🚀 Lancement MS BINGO PACIFIQUE via run.js...');
console.log('🔄 Redirection vers index.js...');

// Rediriger vers le point d'entrée principal
require('./index.js');