Ce répertoire est utilisé par Let's Encrypt pour le défi ACME lors de la vérification du domaine.
Ne pas supprimer ce répertoire, il est nécessaire pour renouveler automatiquement les certificats SSL.