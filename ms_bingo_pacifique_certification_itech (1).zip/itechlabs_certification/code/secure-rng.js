/**
 * MS BINGO PACIFIQUE - RNG Cryptographiquement Sécurisé
 * Version: 1.0.0 - 21 avril 2025
 * 
 * Ce module implémente un générateur de nombres aléatoires cryptographiquement
 * sécurisé pour le jeu de bingo utilisant crypto.randomBytes() au lieu de Math.random()
 */

const crypto = require('crypto');
const fs = require('fs');

class SecureRNG {
  constructor() {
    this.logs = [];
    console.log("SecureRNG initialisé avec crypto.randomBytes()");
  }

  /**
   * Tire un nombre aléatoire entre min et max inclus
   * Utilise crypto.randomBytes() pour garantir une sécurité cryptographique
   * @param {number} min - Valeur minimale incluse
   * @param {number} max - Valeur maximale incluse
   * @returns {number} - Un entier aléatoire dans la plage spécifiée
   */
  drawNumber(min, max) {
    if (min >= max) throw new Error("min doit être inférieur à max");

    const range = max - min + 1;
    const byteSize = 256;
    const limit = byteSize - (byteSize % range);
    let randomByte;

    // Échantillonnage avec rejet pour garantir une distribution uniforme
    do {
      randomByte = crypto.randomBytes(1)[0];
    } while (randomByte >= limit);

    const number = min + (randomByte % range);
    const timestamp = Date.now();
    this.logs.push({ timestamp, number, range: [min, max] });

    return number;
  }

  /**
   * Tire un ensemble de nombres uniques dans une plage donnée
   * @param {number} min - Valeur minimale incluse
   * @param {number} max - Valeur maximale incluse
   * @param {number} count - Nombre d'éléments à tirer
   * @returns {number[]} - Tableau des nombres tirés
   */
  drawUniqueSet(min, max, count) {
    if (count > (max - min + 1)) {
      throw new Error("Impossible de tirer plus de nombres uniques que la taille de la plage");
    }

    // Créer un tableau de tous les nombres possibles
    const allNumbers = Array.from({ length: max - min + 1 }, (_, i) => min + i);
    const result = [];

    // Tirer 'count' nombres uniques
    for (let i = 0; i < count; i++) {
      const randomIndex = this.drawNumber(0, allNumbers.length - 1);
      result.push(allNumbers[randomIndex]);
      allNumbers.splice(randomIndex, 1);
    }

    return result;
  }

  /**
   * Génère un tirage complet de 90 boules
   * @returns {number[]} Tableau des 90 boules dans l'ordre de tirage
   */
  generateCompleteDraw() {
    const boules = Array.from({ length: 90 }, (_, i) => i + 1); // [1, 2, ..., 90]
    const tirage = [];

    while (boules.length > 0) {
      const index = this.drawNumber(0, boules.length - 1);
      const boule = boules.splice(index, 1)[0];
      tirage.push(boule);
    }

    return tirage; // tableau de 90 boules mélangées
  }

  /**
   * Exporte les logs vers un fichier texte
   * @param {string} filePath - Chemin du fichier de destination
   * @returns {boolean} - Succès de l'opération
   */
  exportLogs(filePath = "rng_logs.txt") {
    try {
      const content = this.logs.map(
        (log) => `${new Date(log.timestamp).toISOString()} : ${log.number} (range ${log.range[0]}-${log.range[1]})`
      ).join("\n");

      fs.writeFileSync(filePath, content);
      console.log(`Logs exportés dans ${filePath}`);
      return true;
    } catch (error) {
      console.error(`Erreur lors de l'exportation des logs: ${error.message}`);
      return false;
    }
  }

  /**
   * Récupère les logs au format texte
   * @returns {string} - Contenu des logs
   */
  getLogsText() {
    return this.logs.map(
      (log) => `${new Date(log.timestamp).toISOString()} : ${log.number} (range ${log.range[0]}-${log.range[1]})`
    ).join("\n");
  }
}

module.exports = SecureRNG;