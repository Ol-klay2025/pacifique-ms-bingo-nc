/**
 * MS BINGO PACIFIQUE - Générateur de cartons de bingo
 * Version: 1.0.0 - 21 avril 2025
 * 
 * Ce module utilise le RNG cryptographiquement sécurisé pour générer
 * des cartons de bingo conformes aux règles européennes (3x9 avec 5 numéros par ligne)
 */

const SecureRNG = require('./secure-rng');

/**
 * Génère un carton de bingo européen (3 lignes x 9 colonnes avec 5 numéros par ligne)
 * @returns {number[][]} - Tableau 2D représentant le carton (0 = case vide)
 */
function generateBingoCard() {
  const rng = new SecureRNG();
  const card = Array.from({ length: 3 }, () => Array(9).fill(0));
  
  // Étape 1 : générer 3 numéros par colonne selon la plage traditionnelle
  for (let col = 0; col < 9; col++) {
    const min = col === 0 ? 1 : col * 10;
    const max = col === 8 ? 90 : col * 10 + 9;
    
    const pool = [];
    // Tirer 3 numéros uniques pour cette colonne
    while (pool.length < 3) {
      const n = rng.drawNumber(min, max);
      if (!pool.includes(n)) pool.push(n);
    }
    
    // Trier les nombres par ordre croissant
    pool.sort((a, b) => a - b);
    
    // Placer les nombres dans chaque ligne de cette colonne
    for (let row = 0; row < 3; row++) {
      card[row][col] = pool[row];
    }
  }
  
  // Étape 2 : supprimer 4 numéros par ligne (5 par ligne doivent rester)
  for (let row = 0; row < 3; row++) {
    // Créer un tableau d'indices de colonnes (0-8)
    const filled = Array.from({ length: 9 }, (_, i) => i);
    
    // Mélanger les indices et prendre les 4 premiers pour les cellules à vider
    const toRemove = [];
    while (toRemove.length < 4) {
      const index = rng.drawNumber(0, filled.length - 1);
      toRemove.push(filled[index]);
      filled.splice(index, 1);
    }
    
    // Mettre à 0 les cellules à vider
    for (const col of toRemove) {
      card[row][col] = 0;
    }
  }
  
  return card;
}

/**
 * Valide qu'un carton est conforme aux règles du bingo européen
 * @param {number[][]} card - Carton à valider
 * @returns {boolean} - true si le carton est valide
 */
function validateBingoCard(card) {
  // Vérifier qu'il y a 3 lignes
  if (card.length !== 3) return false;
  
  // Vérifier que chaque ligne a 9 colonnes
  for (let row = 0; row < 3; row++) {
    if (card[row].length !== 9) return false;
  }
  
  // Vérifier que chaque ligne a exactement 5 numéros
  for (let row = 0; row < 3; row++) {
    const nonZeroCount = card[row].filter(n => n !== 0).length;
    if (nonZeroCount !== 5) return false;
  }
  
  // Vérifier que les numéros sont dans les bonnes plages par colonne
  for (let col = 0; col < 9; col++) {
    const min = col === 0 ? 1 : col * 10;
    const max = col === 8 ? 90 : col * 10 + 9;
    
    for (let row = 0; row < 3; row++) {
      const num = card[row][col];
      if (num !== 0 && (num < min || num > max)) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Convertit un carton de bingo en chaîne formatée pour l'affichage
 * @param {number[][]} card - Carton à formater
 * @returns {string} - Représentation textuelle du carton
 */
function formatBingoCard(card) {
  let result = '+-----+-----+-----+-----+-----+-----+-----+-----+-----+\n';
  
  for (let row = 0; row < 3; row++) {
    let line = '|';
    for (let col = 0; col < 9; col++) {
      const num = card[row][col];
      const display = num === 0 ? '     ' : num.toString().padStart(5);
      line += `${display}|`;
    }
    result += line + '\n';
    result += '+-----+-----+-----+-----+-----+-----+-----+-----+-----+\n';
  }
  
  return result;
}

// Exporter les fonctions pour utilisation externe
module.exports = {
  generateBingoCard,
  validateBingoCard,
  formatBingoCard
};