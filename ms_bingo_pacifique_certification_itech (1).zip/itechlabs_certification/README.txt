=====================================================
MS BINGO PACIFIQUE - DOCUMENTATION TECHNIQUE RNG
=====================================================
Version: 1.0.0 - 21 avril 2025
Préparé pour: Certification iTech Labs

-----------------------------------------------------
CONTENU DE L'ARCHIVE
-----------------------------------------------------

1. README.txt - Ce fichier (présentation technique du RNG)

2. /code/ - Implémentation du générateur de nombres aléatoires
   - secure-rng.js - Module RNG cryptographiquement sécurisé
   - generateBingoCard.js - Algorithme de génération de cartons

3. /logs/ - Journaux de tirage et exemples
   - rng_logs.txt - Journal complet d'un tirage de 90 boules
   - card_example.json - Exemple de carton de bingo généré

4. /distribution/ - Tests de distribution statistique
   - distribution-report.md - Rapport détaillé des tests effectués

5. demo_link.txt - Lien vers l'application de démonstration

6. presentation_MS_BINGO.pdf - Présentation complète du projet

-----------------------------------------------------
SPÉCIFICATIONS TECHNIQUES DU RNG
-----------------------------------------------------

Le générateur de nombres aléatoires de MS BINGO PACIFIQUE est implémenté 
en Node.js et utilise la bibliothèque native 'crypto' avec la fonction 
crypto.randomBytes() pour garantir une génération de nombres véritablement 
aléatoire et cryptographiquement sécurisée.

## Caractéristiques principales

1. Entropie cryptographique provenant du système d'exploitation
2. Distribution uniforme statistiquement vérifiée
3. Absence de biais ou de modèles prédictifs
4. Journalisation complète de tous les tirages avec horodatage
5. Conformité aux standards de sécurité ANJ (France)

## Méthode de tirage des boules

Le tirage aléatoire des 90 boules est réalisé selon la méthode suivante:

1. Un tableau de 90 nombres [1-90] est initialisé
2. Pour chaque tirage:
   a. Un index aléatoire est généré via crypto.randomBytes()
   b. La boule correspondant à cet index est retirée du tableau
   c. Cette opération garantit qu'aucune boule ne peut être tirée deux fois

## Génération des cartons de bingo

Les cartons de bingo sont générés selon les règles européennes:
- Grille de 3 lignes × 9 colonnes
- 15 numéros par carton (5 par ligne)
- Distribution par dizaines (col. 1: 1-9, col. 2: 10-19, etc.)

Le processus comprend deux étapes:
1. Attribution de 3 numéros dans chaque colonne selon sa plage
2. Suppression aléatoire de 4 numéros par ligne pour n'en conserver que 5

Tous les nombres aléatoires utilisés pendant ce processus sont générés 
par crypto.randomBytes() pour garantir une sécurité cryptographique.

-----------------------------------------------------
INTERFACE DE TEST ET API
-----------------------------------------------------

L'application de démonstration fournit les endpoints suivants:

- /api/start - Démarre une nouvelle partie
- /api/draw - Tire la boule suivante
- /api/state - Affiche l'état actuel du jeu
- /api/logs - Affiche les logs des tirages
- /api/generate-card - Génère un carton de bingo

Ces endpoints peuvent être utilisés pour vérifier le comportement du RNG
et effectuer des tests statistiques sur sa distribution.

-----------------------------------------------------
CONTACT
-----------------------------------------------------
Pour toute information complémentaire, veuillez contacter:
support@ms-bingo-pacifique.com